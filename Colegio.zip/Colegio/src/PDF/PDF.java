/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PDF;
import colegio.Curso;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import colegio.GestionColegio;
import colegio.Matricula;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author gerardoherreragomez
 */
public class PDF {
    String codA;
    String fecha;
    Document documento;
    FileOutputStream archivo;
    Paragraph titulo;

    ArrayList<Matricula> listaMatriculas;
    
    public PDF(String codA, String fecha, ArrayList<Matricula> listaMatriculas){
        this.codA = codA;
        this.fecha = fecha;
        this.listaMatriculas = listaMatriculas;
        
        documento = new Document();
        titulo = new Paragraph("Reporte de Matriculas");
      
    }
    
    public void crearPDF(){
        try{
            archivo = new FileOutputStream("Reporte_" + codA + ".pdf");
            PdfWriter.getInstance(documento, archivo);
            documento.open();
            titulo.setAlignment(1);
        
            documento.add(titulo);
            
            documento.add(new Paragraph("Codigo_Alumno: " + codA));
            
            documento.add(Chunk.NEWLINE);
            
            PdfPTable tabla = new PdfPTable(6);
            tabla.setWidthPercentage(100);
            PdfPCell nombreCurso = new PdfPCell(new Phrase("Curso"));
            nombreCurso.setBackgroundColor(BaseColor.ORANGE);
            PdfPCell codigoCurso = new PdfPCell(new Phrase("Codigo_Curso"));
            codigoCurso.setBackgroundColor(BaseColor.ORANGE);
            PdfPCell creditosCurso = new PdfPCell(new Phrase("Creditos"));
            creditosCurso.setBackgroundColor(BaseColor.ORANGE);
            PdfPCell nombreDocente = new PdfPCell(new Phrase("Docente"));
            nombreDocente.setBackgroundColor(BaseColor.ORANGE);
            PdfPCell codigoDocente = new PdfPCell(new Phrase("Codigo_Docente"));
            codigoDocente.setBackgroundColor(BaseColor.ORANGE);
            PdfPCell seccionCurso = new PdfPCell(new Phrase("Seccion"));
            seccionCurso.setBackgroundColor(BaseColor.ORANGE);
            
            
            tabla.addCell(nombreCurso);
            tabla.addCell(codigoCurso);
            tabla.addCell(creditosCurso);
            tabla.addCell(nombreDocente);
            tabla.addCell(codigoDocente);
            tabla.addCell(seccionCurso);
            
            for(Matricula matricula: this.listaMatriculas){
                tabla.addCell(matricula.getUnCurso().getNombreCurso());                
                tabla.addCell(matricula.getUnCurso().getCodigoCurso());
                tabla.addCell(matricula.getUnCurso().getCreditos()+"");
                tabla.addCell(matricula.getUnCurso().getUnDocente().getNombre());
                tabla.addCell(matricula.getUnCurso().getUnDocente().getIdentificacion());
                tabla.addCell(matricula.getUnCurso().getSeccion()+"");
                
            }
            documento.add(tabla);          
            documento.add(Chunk.NEWLINE);
            documento.add(new Paragraph("Fecha: " + fecha));
            
            documento.close();
            JOptionPane.showMessageDialog(null, "El archivo PDF se a creado correctamente!");
        } catch (FileNotFoundException e) {
            System.err.println(e.getMessage());
        } catch(DocumentException e){
            System.err.println(e.getMessage());
        }
            
            
            
        }
    
    
    }
    
    
    

