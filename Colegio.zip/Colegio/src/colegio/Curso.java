package colegio;
/**
 * @author CesarCuellar
 */
public class Curso {
    private String codigoCurso;
    private String nombreCurso;
    private int creditos;
    private Docente unDocente;
    private int seccion;
    
    public Curso(String codigo, String nombre, 
            int creditos, Docente unDocente, int seccion) {
        this.codigoCurso = codigo;
        this.nombreCurso = nombre;
        this.creditos = creditos;
        this.unDocente = unDocente;
        this.seccion = seccion;
    }

    public String getCodigoCurso() {
        return codigoCurso;
    }

    public void setCodigoCurso(String codigoCurso) {
        this.codigoCurso = codigoCurso;
    }

    public String getNombreCurso() {
        return nombreCurso;
    }

    public void setNombreCurso(String nombreCurso) {
        this.nombreCurso = nombreCurso;
    }

    public int getCreditos() {
        return creditos;
    }

    public void setCreditos(int creditos) {
        this.creditos = creditos;
    }

    public Docente getUnDocente() {
        return unDocente;
    }

    public void setUnDocente(Docente unDocente) {
        this.unDocente = unDocente;
    }

    public int getSeccion() {
        return seccion;
    }

    public void setSeccion(int seccion) {
        this.seccion = seccion;
    }

     @Override
    public String toString() {
        return this.getNombreCurso() + " COD: " + this.codigoCurso;
    }      
    
    public String mostrarCurso(){
        return this.getNombreCurso() + " COD: " + this.getCodigoCurso()  + " PROFESOR : " + this.getUnDocente().getNombre() + " COD : " + this.getUnDocente().getIdentificacion();
    }
    
}
