/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package colegio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author gerardoherreragomez
 */
public class Archivo {
      FileWriter fw;
       BufferedWriter bw;
       PrintWriter salidaArchivo;
    
       String arch;

    public Archivo(String arch){
        this.arch = arch;
    }
       
           
    public String Abrir() throws IOException{
        fw = new FileWriter(arch);
        bw = new BufferedWriter(fw);
        salidaArchivo = new PrintWriter(bw);
        return "Se abrio el archivo  " + arch;
    }
       
    public String Poner(Object obj)throws IOException{
        salidaArchivo.print(obj + "\n");
        return "se adiciono valor " + obj + "en archivo " + arch;
        
       }       
       
     public String Cerrar()throws IOException{
           salidaArchivo.close();
           return "se cerro archivo " + arch;
     }   
      
}
