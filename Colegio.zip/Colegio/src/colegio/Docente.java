package colegio;
/**
 * @author CesarCuellar
 */
public class Docente extends Persona {    
    private String Profesion;
    public Docente(String nombre, String identificacion, 
            String genero, String profesion) {
        super(nombre, identificacion, genero);
        this.Profesion = profesion;
    }

    public String getProfesion() {
        return Profesion;
    }
    public void setProfesion(String Profesion) {
        this.Profesion = Profesion;
    }
    @Override
    public String toString() {
        return this.getNombre() + "  COD: " + this.getIdentificacion() + " S: " + this.getSexo() + " P: " + this.getProfesion();
    }       
    
    
}