package colegio;
/**
 * @author CesarCuellar
 */
public class Alumno extends Persona{
    private double Ponderado;
    
    public Alumno(String nombre,String id, String sex, double ponde){
        super(nombre,id,sex);
        this.Ponderado = ponde;
    }

    public double getPonderado() {
        return Ponderado;
    }

    public void setPonderado(double Ponderado) {
        this.Ponderado = Ponderado;
    }
    
    @Override
    public String toString() {
        return this.getNombre() + " COD: " + this.getIdentificacion() + "  S: " + this.getSexo() + "  P: " + this.getPonderado();
    }      
    
    
}