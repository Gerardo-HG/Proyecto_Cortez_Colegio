package colegio;
/**
 * @author CesarCuellar
 */
public class Persona {
    private String nombre;
    private String identificacion;
    private String sexo;

    public Persona(String nombre, String identificacion, String sexo) {
        this.nombre = nombre;
        this.identificacion = identificacion;
        this.sexo = sexo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

}
